from abc import ABC, abstractmethod
from dataclasses import dataclass

from calint.entities import LocalConfig, Report


class LintPort(ABC):
    @abstractmethod
    def __init__(self) -> None:
        super().__init__()

    @abstractmethod
    def get_lint_input(self, source):
        raise "method not implemented"

    @abstractmethod
    def get_lint_output(self, source) -> Report:
        raise "method not implemented"


@dataclass
class LinterOptions:
    config: LocalConfig
