from abc import ABC, abstractmethod


class PrinterPort(ABC):
    @abstractmethod
    def __init__(self) -> None:
        super().__init__()

    @staticmethod
    @abstractmethod
    def show(content):
        pass
