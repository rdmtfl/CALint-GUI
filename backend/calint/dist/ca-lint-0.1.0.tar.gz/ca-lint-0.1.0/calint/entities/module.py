from dataclasses import dataclass

from calint.entities.layer import Layer


@dataclass
class Module:
    path: str
    layer: Layer
