from abc import abstractmethod
from typing import Any, Dict

from calint.use_cases.ports import CreateConfigPort


class SerializerAdapter(CreateConfigPort):
    @abstractmethod
    def __init__(self) -> None:
        super().__init__()

    @staticmethod
    @abstractmethod
    def serialize(data: Dict) -> Any:
        raise "method not implemented"

    @staticmethod
    @abstractmethod
    def deserialize(file) -> Any:
        raise "method not implemented"

    @classmethod
    @abstractmethod
    def get_config_input(cls, source: Any):
        string = source.read()
        return cls.deserialize(string)

    @classmethod
    @abstractmethod
    def get_config_output(cls, data: Any):
        return cls.serialize(data)
