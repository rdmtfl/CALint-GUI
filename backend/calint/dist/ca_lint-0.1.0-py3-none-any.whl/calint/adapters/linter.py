from abc import abstractmethod

from typing import Any

from calint.entities import LocalConfig
from calint.use_cases.ports import CreateConfigPort, LintPort


class LinterAdapter(CreateConfigPort, LintPort):
    @abstractmethod
    def __init__(self) -> None:
        super().__init__()

    @classmethod
    @abstractmethod
    def lint(cls, config):
        raise "method not implemented"

    @classmethod
    @abstractmethod
    def config(cls, config):
        raise "method not implemented"

    @classmethod
    @abstractmethod
    def get_config_input(cls, source: Any):
        pass

    @classmethod
    @abstractmethod
    def get_config_output(cls, data: LocalConfig):
        pass

    @classmethod
    @abstractmethod
    def get_lint_input(cls, source: Any):
        pass

    @classmethod
    @abstractmethod
    def get_lint_output(cls, data: Any):
        pass

    @classmethod
    @abstractmethod
    def write_config_output(cls, output: Any):
        pass
