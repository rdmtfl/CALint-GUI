from abc import abstractmethod

from calint.use_cases.ports import PrinterPort


class Presenter(PrinterPort):
    @abstractmethod
    def __init__(self) -> None:
        super().__init__()

    @abstractmethod
    def show(self) -> None:
        raise "Method not implemented"
