from abc import ABC, abstractmethod
from typing import Any, Dict

from calint.entities import LocalConfig


class CreateConfigPort(ABC):
    @abstractmethod
    def __init__(self) -> None:
        super().__init__()

    @classmethod
    @abstractmethod
    def get_config_input(cls, source: Any):
        raise "method not implemented"

    @classmethod
    @abstractmethod
    def get_config_output(cls, data: LocalConfig):
        raise "method not implemented"

    @classmethod
    @abstractmethod
    def write_output(cls, data: Any):
        raise "method not implemented"
