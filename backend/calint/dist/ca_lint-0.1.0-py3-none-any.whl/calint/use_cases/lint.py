from calint.entities import Report
from calint.use_cases.ports import LinterOptions, LintPort, PrinterPort


def lint(linter: LintPort, options: LinterOptions, output: PrinterPort) -> Report:
    report = linter.get_lint_output(
        options.config
    )  # return modules with only their paths

    # fill in layer info
    for r in report.broken_rules:
        start_layer = options.config.find_layer(r.start)
        end_layer = options.config.find_layer(r.end)
        r.start.layer = start_layer
        r.end.layer = end_layer

    output.show(report)
    return report
